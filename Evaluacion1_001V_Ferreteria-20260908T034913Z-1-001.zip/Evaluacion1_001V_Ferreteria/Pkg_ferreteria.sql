CREATE OR REPLACE PACKAGE pkg_ferreteria IS

   -- Excepción global declarada en el paquete
   e_stock_insuficiente EXCEPTION;

   -- Declaración de la función
   FUNCTION calcu_monto_mas_iva (
      p_monto PRODUCTOS.PRECIO_VENTA%TYPE
   ) RETURN NUMBER;

   -- Declaración de procedimientos (bloques anónimos convertidos)
   PROCEDURE validar_stock (
      p_id_producto IN NUMBER,
      p_cant_compra IN NUMBER
   );

   PROCEDURE listar_metodos_pago;

   PROCEDURE consultar_producto_critico;

END pkg_ferreteria;
/

CREATE OR REPLACE PACKAGE BODY pkg_ferreteria IS

   -- =================================================================
   -- 1. FUNCIÓN: CALCU_MONTO_MAS_IVA
   -- =================================================================
   FUNCTION calcu_monto_mas_iva (
      p_monto PRODUCTOS.PRECIO_VENTA%TYPE
   ) RETURN NUMBER IS
      v_total_con_iva NUMBER(12, 2);
   BEGIN 
      v_total_con_iva := p_monto * 1.19;
      RETURN v_total_con_iva;
   END calcu_monto_mas_iva;


   -- =================================================================
   -- 2. PROCEDIMIENTO: VALIDAR STOCK
   -- =================================================================
   PROCEDURE validar_stock (
      p_id_producto IN NUMBER,
      p_cant_compra IN NUMBER
   ) IS
      v_stock_actual NUMBER;
   BEGIN
      SELECT cantidad 
      INTO v_stock_actual
      FROM INVENTARIO
      WHERE id_producto = p_id_producto;

      IF p_cant_compra > v_stock_actual THEN
         RAISE e_stock_insuficiente;
      END IF;

   EXCEPTION
      WHEN e_stock_insuficiente THEN
         DBMS_OUTPUT.PUT_LINE('Error: Stock insuficiente para realizar la compra!!!!');
   END validar_stock;


   -- =================================================================
   -- 3. PROCEDIMIENTO: LISTAR MÉTODOS DE PAGO (VARRAY)
   -- =================================================================
   PROCEDURE listar_metodos_pago IS
      TYPE Multipagos_venta_varray IS VARRAY(3) OF NUMBER;
      v_metodos Multipagos_venta_varray;
      v_nombre_metodo METODOS_PAGO.NOMBRE%TYPE;
   BEGIN
      FOR r_venta IN (SELECT ID_COMPRA_CLIENTE FROM VENTA_CLIENTE ORDER BY ID_COMPRA_CLIENTE) LOOP
          
          IF r_venta.ID_COMPRA_CLIENTE = 1 THEN
              v_metodos := Multipagos_venta_varray(1);
          ELSIF r_venta.ID_COMPRA_CLIENTE = 2 THEN
              v_metodos := Multipagos_venta_varray(3, 4);
          ELSIF r_venta.ID_COMPRA_CLIENTE = 3 THEN
              v_metodos := Multipagos_venta_varray(2);
          ELSE
              v_metodos := Multipagos_venta_varray();
          END IF;

          IF v_metodos.COUNT > 0 THEN
              DBMS_OUTPUT.PUT_LINE(' ');
              DBMS_OUTPUT.PUT_LINE('-> VENTA N° ' || r_venta.ID_COMPRA_CLIENTE || ' (' || v_metodos.COUNT || ' pago(s) procesado(s)):');

              FOR i IN 1..v_metodos.COUNT LOOP
                  SELECT NOMBRE 
                  INTO v_nombre_metodo
                  FROM METODOS_PAGO
                  WHERE ID_METODO_PAGO = v_metodos(i);

                  DBMS_OUTPUT.PUT_LINE('   * Medio #' || i || ': ' || v_nombre_metodo || ' (ID: ' || v_metodos(i) || ')');
              END LOOP;
          END IF;

      END LOOP;
      DBMS_OUTPUT.PUT_LINE(' ');
      DBMS_OUTPUT.PUT_LINE('==================================================');
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
          DBMS_OUTPUT.PUT_LINE('Error: Método de pago no encontrado.');
   END listar_metodos_pago;


   -- =================================================================
   -- 4. PROCEDIMIENTO: PRODUCTO CRÍTICO (RECORD)
   -- =================================================================
   PROCEDURE consultar_producto_critico IS
      TYPE r_producto_critico IS RECORD (
          codigo       PRODUCTOS.CODIGO%TYPE,
          nombre       PRODUCTOS.NOMBRE%TYPE,
          stock_actual INVENTARIO.CANTIDAD%TYPE,
          monto_valor  NUMBER(12,2)
      );
      v_r_prod r_producto_critico;
   BEGIN
      SELECT p.codigo, p.nombre, i.cantidad, (i.cantidad * p.precio_venta)
      INTO v_r_prod
      FROM PRODUCTOS p
      JOIN INVENTARIO i ON p.id_producto = i.id_producto
      WHERE i.cantidad <= i.cantidad_minima
        AND ROWNUM = 1;

      DBMS_OUTPUT.PUT_LINE('ALERTA REABASTECIMIENTO');
      DBMS_OUTPUT.PUT_LINE('Código: ' || v_r_prod.codigo || ' - ' || v_r_prod.nombre);
      DBMS_OUTPUT.PUT_LINE('Stock Alerta: ' || v_r_prod.stock_actual || ' unidades');
      DBMS_OUTPUT.PUT_LINE('Valor Inmovilizado: $' || v_r_prod.monto_valor);

   EXCEPTION
      WHEN NO_DATA_FOUND THEN
          DBMS_OUTPUT.PUT_LINE('Inventario saludable: No hay productos en stock crítico.');
   END consultar_producto_critico;

END pkg_ferreteria;
/


SET SERVEROUTPUT ON;

BEGIN
   -- Probar la función de IVA
   DBMS_OUTPUT.PUT_LINE('Monto con IVA: ' || pkg_ferreteria.calcu_monto_mas_iva(10000));
   
   -- Ejecutar las rutinas del paquete
   pkg_ferreteria.validar_stock(2, 5);
   pkg_ferreteria.listar_metodos_pago;
   pkg_ferreteria.consultar_producto_critico;
END;
/
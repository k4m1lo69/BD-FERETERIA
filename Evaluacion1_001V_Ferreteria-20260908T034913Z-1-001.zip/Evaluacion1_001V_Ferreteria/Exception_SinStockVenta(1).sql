SET SERVEROUTPUT ON;

DECLARE
   v_stock_actual NUMBER;
   v_cant_compra  NUMBER := 5; -- Ejemplo: Cliente quiere comprar 5 unidades
   
   -- Excepción 
   e_stock_insuficiente EXCEPTION;

BEGIN
   -- Consulta del stock actual (Taladro ID = 2, tiene 2 unidades)
   SELECT cantidad 
   INTO v_stock_actual
   FROM INVENTARIO
   WHERE id_producto = 2;

   -- Validación: Si la compra supera el stock disponible
   IF v_cant_compra > v_stock_actual THEN
      RAISE e_stock_insuficiente;
   END IF;

EXCEPTION
   -- Captura de la excepción personalizada
   WHEN e_stock_insuficiente THEN
      DBMS_OUTPUT.PUT_LINE('Error: Stock insuficiente para realizar la compra!!!!');
END;
/
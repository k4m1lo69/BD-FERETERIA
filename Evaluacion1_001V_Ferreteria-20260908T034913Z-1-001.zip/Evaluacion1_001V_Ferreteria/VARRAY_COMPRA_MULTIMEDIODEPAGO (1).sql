SET SERVEROUTPUT ON;

DECLARE
    -- 1. Definición del VARRAY (máximo 5 métodos de pago distintos por venta)
    TYPE Multipagos_venta_varray IS VARRAY(5) OF NUMBER;
    v_metodos Multipagos_venta_varray;
    v_idx     PLS_INTEGER;

    -- Variable auxiliar
    v_nombre_metodo metodos_pago.nombre%TYPE;

    -- Cursor externo: todas las ventas
    CURSOR c_ventas IS
        SELECT id_venta FROM ventas ORDER BY id_venta;

    -- Cursor interno: métodos de pago usados REALMENTE en esa venta
    -- (una venta puede pagarse con más de un método, ej: crédito + transferencia)
    CURSOR c_pagos_venta (p_id_venta NUMBER) IS
        SELECT DISTINCT id_metodo_pago
        FROM pagos
        WHERE id_venta = p_id_venta;

BEGIN
    FOR r_venta IN c_ventas LOOP

        -- 2. Vaciamos el VARRAY para esta venta y lo llenamos con los métodos
        --    de pago que efectivamente están registrados en la tabla PAGOS
        v_metodos := Multipagos_venta_varray();
        v_idx := 0;

        FOR r_pago IN c_pagos_venta(r_venta.id_venta) LOOP
            v_idx := v_idx + 1;
            v_metodos.EXTEND;
            v_metodos(v_idx) := r_pago.id_metodo_pago;
        END LOOP;

        -- 3. Si la venta tiene pagos registrados, los procesamos e imprimimos
        IF v_metodos.COUNT > 0 THEN

            DBMS_OUTPUT.PUT_LINE(' ');
            DBMS_OUTPUT.PUT_LINE('-> VENTA N° ' || r_venta.id_venta || ' (' || v_metodos.COUNT || ' método(s) de pago usado(s)):');

            -- Recorremos el VARRAY ya lleno con datos reales
            FOR i IN 1 .. v_metodos.COUNT LOOP

                SELECT nombre
                INTO v_nombre_metodo
                FROM metodos_pago
                WHERE id_metodo_pago = v_metodos(i);

                DBMS_OUTPUT.PUT_LINE('   * Medio #' || i || ': ' || v_nombre_metodo || ' (ID: ' || v_metodos(i) || ')');

            END LOOP;

        ELSE
            DBMS_OUTPUT.PUT_LINE(' ');
            DBMS_OUTPUT.PUT_LINE('-> VENTA N° ' || r_venta.id_venta || ': sin pagos registrados aún.');
        END IF;

    END LOOP;

    DBMS_OUTPUT.PUT_LINE(' ');
    DBMS_OUTPUT.PUT_LINE('==================================================');

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Error: Método de pago no encontrado.');
END;
/

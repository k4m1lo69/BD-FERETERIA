-- =================================================================
-- CREACIÓN DE FUNCIÓN: CALCU_MONTO_MAS_IVA
-- Propósito: Calcular el precio total de un producto sumándole el 19% de IVA
-- =================================================================
CREATE OR REPLACE FUNCTION CALCU_MONTO_MAS_IVA (
    -- Parámetro de entrada: Recibe el precio base tomando el mismo tipo de dato de la columna PRECIO_VENTA
    p_monto PRODUCTOS.PRECIO_VENTA%TYPE
) 
RETURN NUMBER 
IS 
    -- Variable local para almacenar el monto final calculado (hasta 12 dígitos y 2 decimales)
    v_total_con_iva NUMBER(12, 2);

BEGIN 
    -- 1. Multiplica el monto base por 1.19 para calcular el total con el 19% de IVA incluido
    v_total_con_iva := p_monto * 1.19;
    
    -- 2. Devuelve el resultado del cálculo al programa o consulta que llamó a la función
    RETURN v_total_con_iva;

END CALCU_MONTO_MAS_IVA;
/

-- =================================================================
-- CONSULTA DE PRUEBA SOBRE LA TABLA PRODUCTOS
-- Propósito: Listar el inventario mostrando el precio neto y el precio final con IVA
-- =================================================================
SELECT 
    codigo,                             -- Código único del producto
    nombre,                             -- Descripción del producto
    precio_venta AS precio_neto,        -- Precio almacenado en la BD sin impuestos (Alias: precio_neto)
    CALCU_MONTO_MAS_IVA(precio_venta) AS precio_con_iva -- Llamada a la función pasando el precio_venta
FROM PRODUCTOS;
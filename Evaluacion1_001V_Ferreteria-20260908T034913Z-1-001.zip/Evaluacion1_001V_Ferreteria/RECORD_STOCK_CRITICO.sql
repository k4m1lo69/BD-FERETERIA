SET SERVEROUTPUT ON;

DECLARE
    -- 1. Definición del RECORD
    TYPE r_producto_critico IS RECORD (
        codigo       PRODUCTOS.CODIGO%TYPE,
        nombre       PRODUCTOS.NOMBRE%TYPE,
        stock_actual INVENTARIO.CANTIDAD%TYPE,
        monto_valor  NUMBER(12,2)
    );

    v_r_prod   r_producto_critico;
    v_contador NUMBER := 0;

BEGIN
    DBMS_OUTPUT.PUT_LINE('==================================================');
    DBMS_OUTPUT.PUT_LINE('           ALERTA DE REABASTECIMIENTO            ');
    DBMS_OUTPUT.PUT_LINE('==================================================');

    -- 2. Recorremos el SELECT directamente en el bucle
    FOR r IN (
        SELECT p.codigo, 
               p.nombre, 
               i.cantidad, 
               (i.cantidad * p.precio_venta) AS monto_total
        FROM PRODUCTOS p
        JOIN INVENTARIO i ON p.id_producto = i.id_producto
        WHERE i.cantidad <= i.cantidad_minima
        ORDER BY i.cantidad ASC
    ) LOOP
        -- 3. Carga de datos al RECORD
        v_r_prod.codigo       := r.codigo;
        v_r_prod.nombre       := r.nombre;
        v_r_prod.stock_actual := r.cantidad;
        v_r_prod.monto_valor  := r.monto_total;

        v_contador := v_contador + 1;

        -- 4. Impresión desde el RECORD
        DBMS_OUTPUT.PUT_LINE('Producto #' || v_contador);
        DBMS_OUTPUT.PUT_LINE('  * Código: ' || v_r_prod.codigo || ' - ' || v_r_prod.nombre);
        DBMS_OUTPUT.PUT_LINE('  * Stock Alerta: ' || v_r_prod.stock_actual || ' unidades');
        DBMS_OUTPUT.PUT_LINE('  * Valor Inmovilizado: $' || TO_CHAR(v_r_prod.monto_valor, '999,999,999'));
        DBMS_OUTPUT.PUT_LINE('--------------------------------------------------');
    END LOOP;

    IF v_contador = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Inventario saludable: No hay productos en stock crítico.');
    END IF;

END;
/
SET SERVEROUTPUT ON;

DECLARE
   v_cant_compra NUMBER := 5;
   v_sin_stock   NUMBER := 0; -- Contador de productos con stock insuficiente

   -- Excepción de usuario declarada sin PRAGMA
   e_stock_insuficiente EXCEPTION;

BEGIN
   -- 1. Recorremos los productos haciendo JOIN con la tabla PRODUCTOS
   FOR r IN (
      SELECT i.id_producto, p.nombre, i.cantidad
      FROM INVENTARIO i
      JOIN PRODUCTOS p ON p.id_producto = i.id_producto
   ) LOOP

      IF v_cant_compra > r.cantidad THEN
         DBMS_OUTPUT.PUT_LINE('Producto ID ' || r.id_producto || 
                              ' (' || r.nombre || '): Stock insuficiente. Actual: ' || r.cantidad);
         v_sin_stock := v_sin_stock + 1; -- Incrementamos la alerta
      END IF;

   END LOOP;

   -- 2. Evaluamos fuera del FOR: Si hubo algún problema, lanzamos la excepción
   IF v_sin_stock > 0 THEN
      RAISE e_stock_insuficiente;
   END IF;

EXCEPTION
   -- 3. Capturamos la excepción al final del script
   WHEN e_stock_insuficiente THEN
      DBMS_OUTPUT.PUT_LINE('==================================================');
      DBMS_OUTPUT.PUT_LINE('PROCESO RECHAZADO: Se detectaron ' || v_sin_stock || ' producto(s) sin stock.');
      DBMS_OUTPUT.PUT_LINE('==================================================');
END;
/
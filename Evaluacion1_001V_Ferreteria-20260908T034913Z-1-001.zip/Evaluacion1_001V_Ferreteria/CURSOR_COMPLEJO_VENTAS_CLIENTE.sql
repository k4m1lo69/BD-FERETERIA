SET SERVEROUTPUT ON;

DECLARE
   -- Cursor externo: recibe el id del cliente como parámetro
   CURSOR c_ventas_cliente (p_id_cliente NUMBER) IS
      SELECT id_venta, fecha_venta
      FROM ventas
      WHERE id_cliente = p_id_cliente;

   -- Cursor interno: recibe el id de la venta que entrega el cursor externo
   CURSOR c_detalle_venta (p_id_venta NUMBER) IS
      SELECT dv.cantidad, dv.precio_unitario, dv.descuento, p.nombre
      FROM detalle_ventas dv
      JOIN productos p ON p.id_producto = dv.id_producto
      WHERE dv.id_venta = p_id_venta;

   v_total_venta   NUMBER;
   v_total_cliente NUMBER := 0;
   v_id_cliente    NUMBER := 1;  -- Ejemplo: cliente 1

BEGIN
   DBMS_OUTPUT.PUT_LINE('HISTORIAL DE COMPRAS - CLIENTE ' || v_id_cliente);
   DBMS_OUTPUT.PUT_LINE('=====================================');

   -- Loop externo: recorre cada venta del cliente
   FOR r_venta IN c_ventas_cliente(v_id_cliente) LOOP
      v_total_venta := 0;
      DBMS_OUTPUT.PUT_LINE('Venta N° ' || r_venta.id_venta || ' (' || r_venta.fecha_venta || ')');

      -- Loop interno: recorre el detalle de esa venta
      FOR r_det IN c_detalle_venta(r_venta.id_venta) LOOP
         v_total_venta := v_total_venta
            + (r_det.cantidad * r_det.precio_unitario * (1 - r_det.descuento / 100));
         DBMS_OUTPUT.PUT_LINE('   - ' || r_det.nombre || ' x' || r_det.cantidad);
      END LOOP;

      DBMS_OUTPUT.PUT_LINE('   Subtotal venta: $' || v_total_venta);
      v_total_cliente := v_total_cliente + v_total_venta;
   END LOOP;

   DBMS_OUTPUT.PUT_LINE('=====================================');
   DBMS_OUTPUT.PUT_LINE('Total comprado por el cliente: $' || v_total_cliente);

END;
/

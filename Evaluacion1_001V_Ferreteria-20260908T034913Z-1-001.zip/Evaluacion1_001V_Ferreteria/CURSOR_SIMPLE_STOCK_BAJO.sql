SET SERVEROUTPUT ON;

DECLARE
   -- Cursor simple: no recibe parámetros, siempre trae los mismos productos
   -- (los que están en o bajo su cantidad mínima de reposición)
   CURSOR c_stock_bajo IS
      SELECT p.codigo, p.nombre, i.cantidad, i.cantidad_minima
      FROM productos p
      JOIN inventario i ON i.id_producto = p.id_producto
      WHERE i.cantidad <= i.cantidad_minima;

BEGIN
   DBMS_OUTPUT.PUT_LINE('REPORTE DE PRODUCTOS CON STOCK BAJO');
   DBMS_OUTPUT.PUT_LINE('=====================================');

   FOR r_prod IN c_stock_bajo LOOP
      DBMS_OUTPUT.PUT_LINE(r_prod.codigo || ' - ' || r_prod.nombre
         || ' | Stock actual: ' || r_prod.cantidad
         || ' | Mínimo: ' || r_prod.cantidad_minima);
   END LOOP;

END;
/
